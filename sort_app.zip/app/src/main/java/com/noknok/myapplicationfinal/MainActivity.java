package com.noknok.myapplicationfinal;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.Arrays;

public class MainActivity extends AppCompatActivity {

    private final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.simpleButton);
        EditText edInputString = findViewById(R.id.et_str_to_swap);
        TextView tvSwappedString = findViewById(R.id.tv_swapped_str);

        button.setOnClickListener(v -> {
            int[] array = convertToArray(edInputString.getText().toString());

            sort(array);
            if (isSorted(array)) {
                tvSwappedString.setText(Arrays.toString(array));
            }

        });
    }
    /**
     * The edInputString argument must consist of 0s and 1s.
     * <p>
     * This method converts the inputted string to array of integers and returns it.
     * New array is created from the elements of a string and the size of the array
     * is equal to the length of the string.Each element of the edInputString is converted to integer
     * with parseInt method, that returns the integer value of the argument.
     *@param edInputString is the inputted string
     * @return the converted array of integers
     */
    private int[] convertToArray(String edInputString) {
        int[] array = new int[edInputString.length()];

        for (int i = 0; i < edInputString.length(); i++) {
            array[i] = Integer.parseInt(String.valueOf(edInputString.charAt(i)));
        }
        return array;
    }
    /**
     * The array argument is the array of integers.
     * <p>
     * This method checks the size of the array and sorts it respectively.
     * if the size is greater than 5, it goes through the array and moves all the 1s to the end.
     * Checks if the last index is 1 or not, if yes,the last index decreases and cuts the array,
     * otherwise find 1 from the begining,take it with its left element and interchange with last index and then cut the array.
     * Check if the array is sorted or not, if yes return it, if no continue the sorting process.
     * If the last index becomes 4 (length of the array becomes 5),sort it in other way.
     *
     *  @param array is array of integers that was converted from the string.
     */
    private void sort(int[] array) {
        int lastIndex = array.length - 1;
        int i;
        if (array.length > 5) {
            for (i = 1; i <= lastIndex - 1; i++) {
                Log.i(TAG, "" + i + " " + lastIndex + " " + Arrays.toString(array));

                if (array[lastIndex] == 1) {
                    lastIndex = lastIndex - 1;
                } else {
                    if (array[i] == 1 && i > 0 && i+1 != lastIndex) {
                        swap(array, i - 1, lastIndex - 1);
                        lastIndex = lastIndex - 1;
                    }
                }
                if (isSorted(array)) {
                    Log.i(TAG, "Sorted! " + Arrays.toString(array));
                    Log.i(TAG, "Sorting process is over !!");
                    return;
                }else if(i == lastIndex -1){
                    swap(array,i-1,0);
                    i = 0;
                }
                if (lastIndex == 4) {
                    break;
                }
            }
        }
  /**
 * <p>
 * if the length of the array is equal to 5, go through the loop and check the position of the index. If
 * it is one before the last element check the numbers under that and the last indexes and sort accordingly.
 * If the element is on the last index,check the numbers under that and the previous indexes and sort accordingly.
 * If the index is in other position check if it is equal to 0 and its next is equal to 1. If yes, then check if its next element is under the last index
 * and sort accordingly. Otherwise, check the current index's next's next element if it is 0 or 1. In both cases check the position of the index and sort accordingly.
 */
        if (array.length == 5 || lastIndex == 4) {
            for (i = 0; i <= lastIndex; i++) {
                Log.i(TAG, "Step " + Arrays.toString(array));

                if (i == lastIndex - 1) {
                    if (array[i - 1] == 1 && array[i] == 0 && array[i + 1] == 1) {
                        swap(array, i, i - 3);
                        i = -1;
                    } else if (array[i] == 1 && array[i + 1] == 0) {
                        swap(array, i - 1, i - 3);
                    } else if (array[i] == 0 && array[i + 1] == 1) {
                        swap(array, i - 1, i - 3);
                    } else if (array[i] == 0 && array[i + 1] == 0) {
                        swap(array, i, i - 3);
                    } else if (array[i] == 1 && array[i + 1] == 1) {
                        swap(array, i, i - 2);
                    } else {
                        swap(array, i + 1, i - 3);
                    }
                } else if (i == lastIndex) {
                    if (array[i - 1] == 0 && array[i] == 1) {
                        swap(array, i - 1, i - 4);
                        i = -1;
                    } else if (array[i - 1] == 1 && array[i] == 0) {
                        swap(array, i - 1, i - 3);
                        i = -1;
                    } else {
                        swap(array, i - 2, i - 4);
                    }
                } else {
                    if (array[i] == 0 && array[i + 1] == 1) {
                        if (i + 1 == lastIndex) {
                            if (array[i + 1] == 1) {
                                swap(array, i - 1, i - 3);
                            } else if (array[i + 1] == 0) {
                                swap(array, i, i - 3);
                            }
                        } else {
                            if (array[i + 2] == 0) {
                                if (i + 1 == lastIndex - 2) {
                                    swap(array, i, i + 2);
                                } else if (i + 1 == lastIndex - 3) {
                                    swap(array, i, lastIndex - 1);
                                } else if (i + 1 == lastIndex - 1 && array[i - 1] == 0) {
                                    swap(array, i - 1, i + 1);
                                } else if (i + 1 == lastIndex - 1) {
                                    swap(array, i + 1, i - 2);
                                } else {
                                    swap(array, i, i - 2);
                                }
                            }
                            if (array[i + 2] == 1) {
                                if (i + 1 == lastIndex - 1) {
                                    swap(array, i, i - 2);
                                } else if (i + 2 == lastIndex) {
                                    swap(array, i + 1, i - 2);
                                } else if (i + 2 == lastIndex - 2 && array[i + 3] == 1) {
                                    swap(array, i + 1, lastIndex - 1);
                                } else if (i + 2 == lastIndex - 1) {
                                    swap(array, i + 1, i - 1);
                                } else {
                                    swap(array, i + 1, lastIndex - 1);
                                }
                            }
                        }
                    }
                }
                if (isSorted(array)) {
                    Log.i(TAG, "swapped! " + Arrays.toString(array));
                    return;
                }
            }
        }
    }
    /**
     * This method swaps one pair of elements with another one.
     * <p>
     * Keeps two temporary variables, temp1 keeps the left element and tempp2 keeps the right element of the pair.
     * Then temp1 changes position with the left element of the second pair and the right one changes its position with the right element of the second pair.
     *    @param array is array of integers that was converted from the string.
     *    @param firsPair is the left element of the first pair.
     *    @param secondPair is the left element of the second pair.
     */
    private void swap(int[] array, int firsPair, int secondPair) {
        int temp1 = array[firsPair];
        int temp2 = array[firsPair + 1];
        array[firsPair] = array[secondPair];
        array[firsPair + 1] = array[secondPair + 1];
        array[secondPair] = temp1;
        array[secondPair + 1] = temp2;
    }
    /**
     * Intended for checking if array is sorted or not
     * If array element is greater than its next element, then arrat is not sorted, otherwise it is sorted.
     * @return true if array is sorted otherwise false
     *  @param array is array of integers that was converted from the string.
     */
    private boolean isSorted(int[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            if (array[i] > array[i + 1]) {
                return false;
            }
        }
        return true;
    }
}